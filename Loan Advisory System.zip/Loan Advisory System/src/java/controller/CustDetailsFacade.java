/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import model.CustDetails;

/**
 *
 * @author 968124331v
 */
@Stateless
public class CustDetailsFacade extends AbstractFacade<CustDetails> {

    @PersistenceContext(unitName = "Loan_Advisory_SystemPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public CustDetailsFacade() {
        super(CustDetails.class);
    }
    
}
