/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author 968124331v
 */
@Entity
@Table(name = "cust_details")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CustDetails.findAll", query = "SELECT c FROM CustDetails c"),
    @NamedQuery(name = "CustDetails.findByCid", query = "SELECT c FROM CustDetails c WHERE c.cid = :cid"),
    @NamedQuery(name = "CustDetails.findByNic", query = "SELECT c FROM CustDetails c WHERE c.nic = :nic"),
    @NamedQuery(name = "CustDetails.findByName", query = "SELECT c FROM CustDetails c WHERE c.name = :name"),
    @NamedQuery(name = "CustDetails.findByPhnNum", query = "SELECT c FROM CustDetails c WHERE c.phnNum = :phnNum"),
    @NamedQuery(name = "CustDetails.findByAccntNum", query = "SELECT c FROM CustDetails c WHERE c.accntNum = :accntNum")})
public class CustDetails implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "cid")
    private Integer cid;
    @Pattern(regexp="^(?:19|20)?\\d{2}(?:[01235678]\\d\\d(?<!(?:000|500|36[7-9]|3[7-9]\\d|86[7-9]|8[7-9]\\d)))\\d{4}(?i:v|x)$",message="Invalid NIC number,shold be as 960000000v/V")
    @Size(max = 12)
    @Column(name = "nic")
    private String nic;
    @Size(max = 45)
    @Column(name = "name")
    private String name;
    @Pattern(regexp="^\\(?(\\d{3})\\)?[- ]?(\\d{3})[- ]?(\\d{4})$", message="Invalid phone format, should be as xxx-xxx-xxxx")
    @Size(max = 10)
    @Column(name = "phn_num")
    private String phnNum;
    @Size(max = 10)
    @Column(name = "accnt_num")
    private String accntNum;

    
    public CustDetails(){
        
    }

    public CustDetails(Integer cid) {
        this.cid = cid;
    }

    public Integer getCid() {
        return cid;
    }

    public void setCid(Integer cid) {
        this.cid = cid;
    }

    public String getNic() {
        return nic;
    }

    public void setNic(String nic) {
        this.nic = nic;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhnNum() {
        return phnNum;
    }

    public void setPhnNum(String phnNum) {
        this.phnNum = phnNum;
    }

    public String getAccntNum() {
        return accntNum;
    }

    public void setAccntNum(String accntNum) {
        this.accntNum = accntNum;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cid != null ? cid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CustDetails)) {
            return false;
        }
        CustDetails other = (CustDetails) object;
        if ((this.cid == null && other.cid != null) || (this.cid != null && !this.cid.equals(other.cid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.CustDetails[ cid=" + cid + " ]";
    }

}
