/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

/**
 *
 * @author 968124331v
 */
@ManagedBean(name="purpose_Data")
@RequestScoped
public class Purpose_data {

   private String purpose;
   
   private List<String> purpose_list=new ArrayList<>();
    public List<String>  get_purpose_name(){
        try {
            Connection connection=null;
            Class.forName("com.mysql.jdbc.Driver");
            connection=DriverManager.getConnection("jdbc:mysql://localhost:3307/loan_advisory","root","root");
            PreparedStatement ps=null;
            ps=connection.prepareStatement("select * from purpose ");
            System.out.println(ps); 
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
               purpose_list.add(rs.getString("purpose_name"));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return purpose_list;
    }
    public Purpose_data() {
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }

    public List<String> getPurpose_list() {
        return purpose_list;
    }

    public void setPurpose_list(List<String> purpose_list) {
        this.purpose_list = purpose_list;
    }
    
}
