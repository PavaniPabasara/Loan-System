/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

/**
 *
 * @author 968124331v
 */
@ManagedBean(name="seg_Data")
@RequestScoped
public class Seg_Data {

    private String segment;
    
    
    private List<String> segment_list=new ArrayList<>();
    public List<String>  get_segment_name(){
      try {
            Connection connection=null;
            Class.forName("com.mysql.jdbc.Driver");
            connection=DriverManager.getConnection("jdbc:mysql://localhost:3307/loan_advisory","root","root");
            PreparedStatement ps=null;
            ps=connection.prepareStatement("select * from segments");
            System.out.println(ps); 
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
                segment_list.add(rs.getString("sid")+"   "+rs.getString("segment_name"));
                
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return segment_list;
    }
    
    public Seg_Data() {
        
    }
    
    public String getSegment() {
        return segment;
    }

    public void setSegment(String segment) {
        this.segment = segment;
    }

    public List<String> getSegment_list() {
        return segment_list;
    }

    public void setSegment_list(List<String> segment_list) {
        this.segment_list = segment_list;
    }
    
    
    
}
