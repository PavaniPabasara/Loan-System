/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

/**
 *
 * @author 968124331v
 */
@ManagedBean(name="schemeBean")
@RequestScoped
public class schemeBean {

public List<scheme> getschemeList()
{
List<scheme> list = new ArrayList<scheme>();
PreparedStatement ps = null;
Connection con = null;
ResultSet rs = null;
try
{
Class.forName("com.mysql.jdbc.Driver");
con = DriverManager.getConnection("jdbc:mysql://localhost:3307/loan_advisory","root","root");
String sql = "select * from scheme_details";
ps= con.prepareStatement(sql); 
rs= ps.executeQuery(); 
while (rs.next())
{
scheme schm = new scheme();
schm.setSchemeName(rs.getString("schemeName"));
schm.setDescription(rs.getString("description"));

list.add(schm);
} 
}
catch(Exception e)
{
e.printStackTrace();
}
finally
{
try
{
con.close();
ps.close();
}
catch(Exception e)
{
e.printStackTrace();
}
}
return list;
}
}
/*    public schemeBean() {
}*/
    

