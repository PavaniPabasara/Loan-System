/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author 968124331v
 */
@Entity
@Table(name = "cust_request")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CustRequest.findAll", query = "SELECT c FROM CustRequest c"),
    @NamedQuery(name = "CustRequest.findByRid", query = "SELECT c FROM CustRequest c WHERE c.rid = :rid"),
    @NamedQuery(name = "CustRequest.findByNic", query = "SELECT c FROM CustRequest c WHERE c.nic = :nic"),
    @NamedQuery(name = "CustRequest.findBySegment", query = "SELECT c FROM CustRequest c WHERE c.segment = :segment"),
    @NamedQuery(name = "CustRequest.findByPurpose", query = "SELECT c FROM CustRequest c WHERE c.purpose = :purpose"),
    @NamedQuery(name = "CustRequest.findByAmount", query = "SELECT c FROM CustRequest c WHERE c.amount = :amount")})
public class CustRequest implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "rid")
    private Integer rid;
    @Size(max = 12)
    @Column(name = "nic")
    private String nic;
    @Size(max = 45)
    @Column(name = "segment")
    private String segment;
    @Size(max = 45)
    @Column(name = "purpose")
    private String purpose;
    @Column(name = "amount")
    private Integer amount;

    public CustRequest() {
    }

    public CustRequest(Integer rid) {
        this.rid = rid;
    }

    public Integer getRid() {
        return rid;
    }

    public void setRid(Integer rid) {
        this.rid = rid;
    }

    public String getNic() {
        return nic;
    }

    public void setNic(String nic) {
        this.nic = nic;
    }

    public String getSegment() {
        return segment;
    }

    public void setSegment(String segment) {
        this.segment = segment;
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }

    public Integer getAmount() {
        return amount;
    }

    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (rid != null ? rid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CustRequest)) {
            return false;
        }
        CustRequest other = (CustRequest) object;
        if ((this.rid == null && other.rid != null) || (this.rid != null && !this.rid.equals(other.rid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.CustRequest[ rid=" + rid + " ]";
    }
    
}
